PPL-LAB
Assignments of PPL lab 
Mis- 111903090
