import turtle

s = turtle.getscreen()
t = turtle.Turtle()


class shape:
    def __init__(self):
        pass
    def dimension(self):
        print("Shape is 2-Dimensional")


class Circle(shape):
    def __init__(self, radius=0):
        self.radius=radius
    def info(self):
        print("A circle is all points in the same plane that lie at an equal distance from a center point.")
    def show(self):
        t.circle(self.radius)


class polygon(shape):
    def __init__(self, sides=0, length=0):
        self.sides = sides
        self.length = length
    def info(self):
        print("In geometry, a polygon can be defined as a flat or plane, two-dimensional  with straight sides.")


class square(polygon):
    def show(self):
        t.fd(self.length)
        t.rt(90)
        t.fd(self.length)
        t.rt(90)
        t.fd(self.length)
        t.rt(90)
        t.fd(self.length)
        t.rt(90)


class pentagon(polygon):
    def show(self):
        for i in range(5):
            t.forward(self.length)
            t.right(72)


class hexagon(polygon):
    def show(self):
        for i in range(6):
            t.forward(self.length)
            t.right(60)


class octagon(polygon):
    def show(self):
        for i in range(8):
            t.forward(self.length)
            t.right(45)


class triangle(polygon):
    def show(self):
        t.forward(self.length)
        t.left(120)
        t.forward(self.length)
        t.left(120)
        t.forward(self.length)


sh1 = octagon(8, 100)
sh1.dimension()
sh1.info()
sh1.show()

s._root.mainloop()